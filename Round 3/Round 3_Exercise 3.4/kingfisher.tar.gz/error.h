/* error.h */

void error(int code);
